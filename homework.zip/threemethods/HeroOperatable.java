package com.train.homework12.threemethods;

import java.util.List;

/**
 * @author 吴佳峰
 * @date 2019-08-06 15:25
 */
public interface HeroOperatable {
    /**
     * 按名称进行模糊查找
     * @param sName
     * @return
     */
    List<Hero> findByNameLike(String sName);

    /**
     *根据id进行排序（降序）的操作
     * @return
     */
    List<Hero> findOrderById();

    /**
     *根据姓名模糊查找并排序（升序），然后分页获取数据
     * @param sName
     * @param currPage
     * @param pageSize
     * @return
     */
    List<Hero> findByNameLikeOrderLimit(String sName,int currPage, int pageSize);

}
