package com.train.homework12.threemethods;

import java.util.List;
import java.util.Scanner;

/**
 * @author 吴佳峰
 * @date 2019-08-06 16:58
 */
public class Main {
    public static void main(String[] args) {
        //循环测试3个方法
        boolean isRunning = true;
        Scanner scanner = new Scanner(System.in);
        while (isRunning) {
            System.out.println("输入1，进行姓名模糊查找");
            System.out.println("输入2，根据id进行排序操作（降序）");
            System.out.println("输入3，据姓名模糊查找并排序（升序），然后分页获取数据");
            System.out.println("输入4，退出");
            String input = scanner.nextLine();
            switch (input) {
                case "1":
                    findByNameLike();
                    break;
                case "2":
                     findOrderById();
                     break;
                case "3":
                     findByNameLikeOrderLimit();
                case "4":
                    isRunning = false;
            }
        }
    }

    /**
     * 调用findByNameLike方法
     */
    public static void findByNameLike() {
        System.out.println("请输入要查找的姓名");
        Scanner scanner = new Scanner(System.in);
        String s1 = scanner.nextLine();
        HeroOperator heroOperator = new HeroOperator();
        List<Hero> heroList = heroOperator.findByNameLike(s1);
        heroList.forEach(System.out::println);
    }

    /**
     * 调用findOrderById方法
     */
    public static void findOrderById(){
        HeroOperator heroOperator = new HeroOperator();
        List<Hero> heroList = heroOperator.findOrderById();
        heroList.forEach(System.out::println);
    }

    /**
     * 调用findByNameLikeOrderLimit方法
     */
    public static void findByNameLikeOrderLimit(){
        System.out.println("请输入要查找的姓名");
        Scanner scanner = new Scanner(System.in);
        String s1 = scanner.nextLine();
        System.out.println("请输入每页显示的条数");
        int pageSize = scanner.nextInt();
        System.out.println("请输入想看的页数");
        int currPage = scanner.nextInt();
        HeroOperator heroOperator = new HeroOperator();
        List<Hero> heroList = heroOperator.findByNameLikeOrderLimit(s1,currPage,pageSize);
        heroList.forEach(System.out::println);
    }
}
