package com.train.homework12.threemethods;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 吴佳峰
 * @date 2019-08-06 15:34
 */
public class HeroOperator implements HeroOperatable {

    /**
     * 按名称进行模糊查找
     *
     * @param sName
     * @return
     */
    @Override
    public List<Hero> findByNameLike(String sName) {
        //建立数据库的连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        //第一个方法分别用了Statement和PreparedStatement进行练习
        //Statement statement = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List<Hero> heroList = new ArrayList<>();
        try {
            //statement = connection.createStatement();
            //sql语句
            String sql = "select * from hero where sname like ?";
            preparedStatement = connection.prepareStatement(sql);
            //模糊查询在这里拼接%
            preparedStatement.setObject(1, "%" + sName + "%");
            //String sql = "select * from hero where sname"+"='"+sName+"'";
            //返回结果集对象
            rs = preparedStatement.executeQuery();
            //rs = statement.executeQuery(sql);
            //遍历结果集
            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                Date sbirthday = rs.getDate(5);
                int sage = rs.getInt(6);
                Hero hero = new Hero();
                hero.setId(id);
                hero.setSno(sno);
                hero.setSname(sname);
                hero.setSsex(ssex);
                hero.setSbirthday(sbirthday);
                hero.setSage(sage);
                heroList.add(hero);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            JdbcUtil.getInstance().closeResource(rs);
            JdbcUtil.getInstance().closeResource(preparedStatement);
            //JdbcUtil.getInstance().closeResource(statement);
            JdbcUtil.getInstance().closeResource(connection);
        }
        return heroList;
    }

    @Override
    public List<Hero> findOrderById() {
        //建立数据库连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List<Hero> heroList = new ArrayList<>();
        try {
            //sql语句排序
            String sql = "select * from hero order by id desc";
            preparedStatement = connection.prepareStatement(sql);
            //返回结果集对象
            rs = preparedStatement.executeQuery();
            //遍历结果集对象
            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                Date sbirthday = rs.getDate(5);
                int sage = rs.getInt(6);
                Hero hero = new Hero();
                hero.setId(id);
                hero.setSno(sno);
                hero.setSname(sname);
                hero.setSsex(ssex);
                hero.setSbirthday(sbirthday);
                hero.setSage(sage);
                heroList.add(hero);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            JdbcUtil.getInstance().closeResource(rs);
            JdbcUtil.getInstance().closeResource(preparedStatement);
            JdbcUtil.getInstance().closeResource(connection);
        }
        return heroList;
    }

    @Override
    public List<Hero> findByNameLikeOrderLimit(String sName, int currPage, int pageSize) {
         //建立数据库的连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List<Hero> heroList = new ArrayList<>();
        try {
            //sql语句,用limit实现分页功能
            String sql = "select * from hero where sname like ? order by sname asc limit ?,?";
            preparedStatement = connection.prepareStatement(sql);
            //模糊查询在这里拼接%
            preparedStatement.setObject(1, "%" + sName + "%");
            //为limit参数赋值
            preparedStatement.setObject(2,(currPage-1)*pageSize);
            preparedStatement.setObject(3,pageSize);
            //返回结果集对象
            rs = preparedStatement.executeQuery();
            //遍历结果集
            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                Date sbirthday = rs.getDate(5);
                int sage = rs.getInt(6);
                Hero hero = new Hero();
                hero.setId(id);
                hero.setSno(sno);
                hero.setSname(sname);
                hero.setSsex(ssex);
                hero.setSbirthday(sbirthday);
                hero.setSage(sage);
                heroList.add(hero);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            JdbcUtil.getInstance().closeResource(rs);
            JdbcUtil.getInstance().closeResource(preparedStatement);
            JdbcUtil.getInstance().closeResource(connection);
        }
        return heroList;
    }
}
