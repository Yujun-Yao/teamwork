package com.train.homework12.transation;

import com.train.homework12.threemethods.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author 吴佳峰
 * @date 2019-08-06 19:36
 */
public class Transation {
    public static void main(String[] args) {
        saveMoney();
    }
    /**
     * 存钱，根据存钱的数量，账户里的钱产生相应的变化
     */
    public static void saveMoney() {
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        try {
            //手动关闭提交功能
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            String sql = "insert into bank values(null,1,200)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeQuery();
            //回滚，使rollback所在事务之前的所有sql执行失效
            connection.rollback();

            String sql2 = "update people set money = money-200 where id=1";
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();
            //提交修改
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            if(null!=preparedStatement){
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }if(null!=connection){
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }


}
