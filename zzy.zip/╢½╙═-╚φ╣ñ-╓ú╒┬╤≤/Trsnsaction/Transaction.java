package com.train.day16.homework;

import com.train.day16.JdbcUtil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author 郑章洋
 * @date 2019-08-06 16:34
 */
public class Transaction {
    public static void main(String[] args) {
        try {
            upOrderAndChangeStore();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void  upOrderAndChangeStore() throws IOException {
        // 获取连接
        Connection connection = JdbcUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            // 关闭自动提交，需要手动提交 在库存减少后再提交
            connection.setAutoCommit(false);
            // 添加订单
            String sqlInsert = "insert into torder values(null,2,5)";
            preparedStatement = connection.prepareStatement(sqlInsert);
            preparedStatement.executeUpdate();

            String sqlUpdate = "update ticket set number = number - 5 where tid = 2";
            preparedStatement = connection.prepareStatement(sqlUpdate);
            preparedStatement.executeUpdate();

            connection.commit();
            System.out.println("提交订单成功，票数更新");
        } catch (SQLException e) {
            System.out.println("提交订单失败，票数更新失败");
            e.printStackTrace();
        }finally {
            // 关闭资源
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
    }
}
