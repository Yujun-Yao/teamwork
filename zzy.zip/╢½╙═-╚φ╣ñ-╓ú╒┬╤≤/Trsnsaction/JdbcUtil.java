package com.train.day16;

import com.train.day15.Hero;
import org.junit.Test;

import java.io.*;
import java.sql.*;
import java.util.Properties;

/**
 * @author 郑章洋
 * @date 2019-08-06 10:02
 */
public class JdbcUtil {
    public static void main(String[] args) {
        Hero hero = new Hero();
        hero.setSno("37");
        hero.setSname("ff");
        hero.setSsex("M");
        hero.setSage(22);
        try {
            insertHero(hero);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // SRC ->ClassPath
    @Test
    public static Connection getConnection() throws IOException {
        // 操作Properties文件的工具类
        Properties properties = new Properties();
        // 获取当前项目文件路径，ClassPath（编译后路径）
        String filePath = JdbcUtil.class.getResource("/").getFile().toString()+"jdbc.properties";
        // 输入流
        InputStream is = new FileInputStream(filePath);
        // 加载输入流
        properties.load(is);
        try {
            // 获取driver信息，返回object对象，需要使用强转String
            Class.forName(properties.get("driver").toString());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Connection connection = null;
        try {
            // 乱码在url后追加编码
            connection = DriverManager.getConnection(properties.get("url").toString(),properties.get("username").toString(),properties.get("password").toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    public static void insertHero(Hero hero) throws IOException {
        Connection connection = getConnection();
        ResultSet rs = null;
        // sql语句中未知的值使用问号（占位符）代替，其后再设置值
        String sql = "insert into hero values(null,?,?,?,?)";
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            // 为占位符依次设置值
            preparedStatement.setString(1,hero.getSno());
            preparedStatement.setString(2,hero.getSname());
            preparedStatement.setString(3,hero.getSsex());
            preparedStatement.setInt(4,hero.getSage());
            rs= preparedStatement.executeQuery();
            if(rs.next()){
                System.out.print(rs.getInt(1));
                System.out.print(rs.getInt(2));
                System.out.print(rs.getInt(3));
                System.out.print(rs.getInt(4));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            closeResource(preparedStatement);
            closeResource(connection);
        }
    }
    /**
     * 关闭资源
     *
     * @param autoCloseable
     */
    public static void closeResource(AutoCloseable autoCloseable) {
        if (null != autoCloseable) {
            try {
                autoCloseable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
