package com.train.day15;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author 郑章洋
 * @date 2019-08-05 15:45
 */
public class JdbcUtil {
    private static final JdbcUtil JDBC_UTIL = new JdbcUtil();
    private JdbcUtil(){

    }

    public static JdbcUtil getInstance(){
        return JDBC_UTIL;
    }

    public Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Connection connection = null;
        try {
            // 乱码在url后追加编码
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/train","root","123456");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
