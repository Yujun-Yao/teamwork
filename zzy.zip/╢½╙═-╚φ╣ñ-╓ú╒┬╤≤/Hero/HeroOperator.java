package com.train.day15;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 郑章洋
 * @date 2019-08-05 15:44
 */
public class HeroOperator implements HeroOperatable {
    /**
     * 查询所有数据
     *
     * @return 将所有数据封装到集合返回
     */
    @Override
    public List<Hero> findAllHero() {
        // 获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        ResultSet rs = null;
        Statement statement = null;
        List<Hero> heroList = new ArrayList<>();
        try {
            statement = connection.createStatement();
            String sql = "select * from hero";
            rs = statement.executeQuery(sql);
            System.out.println(sql);
            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                int sage = rs.getInt(5);

                Hero hero = new Hero();
                hero.setId(id);
                hero.setSname(sname);
                hero.setSno(sno);
                hero.setSsex(ssex);
                hero.setSage(sage);
                heroList.add(hero);
            }
            // heroList.forEach(System.out::println);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            closeResource(rs);
            closeResource(statement);
            closeResource(connection);
        }

        return heroList;
    }

    /**
     * 修改信息
     *
     * @param hero 待修改的对象
     * @return 执行sql后，受影响的行数
     */
    @Override
    public int updateHeroById(Hero hero) {
        Connection connection = JdbcUtil.getInstance().getConnection();
        Statement statement = null;
        int id = hero.getId();
        try {
            statement = connection.createStatement();
            //String sql = "update hero set sname = '" + "孙悟空" + "' where id = "+id;
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("update hero set sno =");
            stringBuffer.append("'");
            stringBuffer.append(hero.getSno());
            stringBuffer.append("',sname ='");
            stringBuffer.append(hero.getSname());
            stringBuffer.append("',ssex ='");
            stringBuffer.append(hero.getSsex());
            stringBuffer.append("',sage ='");
            stringBuffer.append(hero.getSage());
            stringBuffer.append("'where id =");
            stringBuffer.append(id);

            System.out.println(stringBuffer.toString());
            int affectedRows = statement.executeUpdate(stringBuffer.toString());
            System.out.println(stringBuffer.toString());
            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResource(statement);
            closeResource(connection);
        }
        return 0;
    }

    /**
     * 添加数据
     *
     * @param hero
     * @return 执行sql后，受影响的行数
     */
    @Override
    public int insertHero(Hero hero) {
        Connection connection = JdbcUtil.getInstance().getConnection();
        Statement statement = null;
        try {

            statement = connection.createStatement();
            //String sql = "insert into hero()value ()";
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("insert into hero values(null,");
            stringBuffer.append("'");
            stringBuffer.append(hero.getSno());
            stringBuffer.append("','");
            stringBuffer.append(hero.getSname());
            stringBuffer.append("','");
            stringBuffer.append(hero.getSsex());
            stringBuffer.append("',");
            stringBuffer.append(hero.getSage());
            stringBuffer.append(")");

            System.out.println(stringBuffer.toString());

            int affectedRows = statement.executeUpdate(stringBuffer.toString());
            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResource(statement);
            closeResource(connection);
        }
        return 0;
    }

    /*** 删除数据
     * @param id
     * @return 执行sql后，受影响的行数
     */
    @Override
    public int deleteHeroById(int id) {
        Connection connection = JdbcUtil.getInstance().getConnection();
        Statement statement = null;
        try {
            statement = connection.createStatement();
            String sql = "delete from hero where id =" + id;
            System.out.println(sql);

            int affectedRows = statement.executeUpdate(sql);
            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResource(statement);
            closeResource(connection);
        }
        return 0;
    }

    /**
     * 按名字模糊查询
     *
     * @param userName
     * @return
     */
    @Override
    public List<Hero> findByHeroNameLike(String userName) {
        // 获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        ResultSet rs = null;
        List<Hero> heroList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        try {
            String sql = "select * from hero where sname like ?";

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, "%" + userName + "%");

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                int sage = rs.getInt(5);

                Hero hero = new Hero();
                hero.setId(id);
                hero.setSname(sname);
                hero.setSno(sno);
                hero.setSsex(ssex);
                hero.setSage(sage);
                heroList.add(hero);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            closeResource(rs);
            closeResource(preparedStatement);
            closeResource(connection);
        }
        return heroList;
    }

    /**
     * 按年龄排序
     *
     * @return
     */
    @Override
    public List<Hero> findOrderByHeroAge() {
        // 获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        ResultSet rs = null;
        List<Hero> heroList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        try {
            String sql = "select * from hero order by sage desc";

            preparedStatement = connection.prepareStatement(sql);

            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                int sage = rs.getInt(5);

                Hero hero = new Hero();
                hero.setId(id);
                hero.setSname(sname);
                hero.setSno(sno);
                hero.setSsex(ssex);
                hero.setSage(sage);
                heroList.add(hero);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            closeResource(rs);
            closeResource(preparedStatement);
            closeResource(connection);
        }
        return heroList;
    }

    /**
     * 按名字查询排序分页
     *
     * @param userName 查找和排序的关键词
     * @param currPage 第几页
     * @param pageSize 每页展示几条数据
     * @return
     */
    @Override
    public List<Hero> findByHeroNameLikeOrderLimit(String userName, int currPage, int pageSize) {
        // 获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        ResultSet rs = null;
        // 创建列表用于接受返回集合
        List<Hero> heroList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        try {
            String sql = "select * from hero where sname = ? order by sname asc limit ?,?";
            preparedStatement = connection.prepareStatement(sql);
            // 插入sql参数
            preparedStatement.setString(1, userName);
            preparedStatement.setInt(2, (currPage - 1) * pageSize);
            preparedStatement.setInt(3, pageSize);
            // 执行查询
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String sno = rs.getString(2);
                String sname = rs.getString(3);
                String ssex = rs.getString(4);
                int sage = rs.getInt(5);
                // 把查出的信息装入Hero 再装入集合
                Hero hero = new Hero();
                hero.setId(id);
                hero.setSname(sname);
                hero.setSno(sno);
                hero.setSsex(ssex);
                hero.setSage(sage);
                heroList.add(hero);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            closeResource(rs);
            closeResource(preparedStatement);
            closeResource(connection);
        }
        return heroList;
    }

    /**
     * 关闭资源
     *
     * @param autoCloseable
     */
    public static void closeResource(AutoCloseable autoCloseable) {
        if (null != autoCloseable) {
            try {
                autoCloseable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
