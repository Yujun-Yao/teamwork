package com.train.day15;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * @author 郑章洋
 * @date 2019-08-05 16:07
 */
public class HeroOperatorTest {
    // 实例化一个实现接口类，用于后面调用方法
    HeroOperator heroOperator = new HeroOperator();

    /**
     * 查询所有英雄
     */
    @Test
    public void findAllHero() {
        List<Hero> list = heroOperator.findAllHero();
        list.forEach(System.out::println);

    }

    /**
     * 修改英雄信息
     */
    @Test
    public void updateHeroById() {
        Hero hero = new Hero();
        hero.setSsex("M");
        hero.setSname("八戒");
        hero.setSno("232");
        hero.setSage(56);
        hero.setId(3);
        int refectedRows = heroOperator.updateHeroById(hero);
        System.out.println(refectedRows);
    }

    /**
     * 插入英雄
     */
    @Test
    public void insertHero() {
        Hero hero = new Hero();
        hero.setSsex("M");
        hero.setSname("嫦娥");
        hero.setSno("22");
        hero.setSage(56);
        int refectedRows = heroOperator.insertHero(hero);
        System.out.println(refectedRows);
    }

    /**
     * 按id删除英雄
     */
    @Test
    public void deleteHeroById() {
        int refectedRows = heroOperator.deleteHeroById(1);
        System.out.println(refectedRows);
    }

    /**
     * 按名字模糊查询
     */
    @Test
    public void findByHeroNameLike() {
        String userName = "娥";
        List<Hero> list = heroOperator.findByHeroNameLike(userName);
        list.forEach(System.out::println);
    }

    /**
     * 按英雄名字排序
     */
    @Test
    public void findOrderByHeroSno() {
        List<Hero> list = heroOperator.findOrderByHeroAge();
        list.forEach(System.out::println);
    }

    /**
     * 按英雄名字查询排序分页
     */
    @Test
    public void findByHeroNameLikeOrderLimit() {
        List<Hero> list = heroOperator.findByHeroNameLikeOrderLimit("ff", 2, 2);
        list.forEach(System.out::println);
    }

    @Test
    public void closeResource() {
    }
}