package com.train.day15;

import java.util.List;

/**
 * @author 郑章洋
 * @date 2019-08-05 15:37
 */
public interface HeroOperatable {
    /**
     * 查询所有数据
     * @return 将所有数据封装到集合返回
     */
    List<Hero> findAllHero();

    /**
     * 修改信息
     * @param hero 待修改的对象
     * @return 执行sql后，受影响的行数
     */
    int updateHeroById(Hero hero);

    /**
     * 添加数据
     * @param hero
     * @return 执行sql后，受影响的行数
     */
    int insertHero(Hero hero);

    /**
     * 删除数据
     * @param id
     * @return 执行sql后，受影响的行数
     */
    int deleteHeroById(int id);

    /**
     * 按照名字模糊查询数据
     * @param userName
     * @return 返回符合的数据封装到集合返回
     */
    List<Hero> findByHeroNameLike(String userName);

    /**
     * 根据名字降序排序
     * @return 返回排序后的集合
     */
    List<Hero> findOrderByHeroAge();

    /**
     * 根据名字查找并排序（升序），每页两条数据
     * @param userName 查找和排序的关键词
     * @param currPage 第几页
     * @param pageSize 每页展示几条数据
     * @return
     */
    List<Hero> findByHeroNameLikeOrderLimit(String userName,int currPage,int pageSize);
}
